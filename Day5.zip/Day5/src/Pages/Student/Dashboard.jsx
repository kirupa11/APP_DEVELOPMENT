import React from 'react';

const Dashboard = () => {
    return (
        <div>
            <h1>dashboard page</h1>
        </div>
    );
};

export default Dashboard;