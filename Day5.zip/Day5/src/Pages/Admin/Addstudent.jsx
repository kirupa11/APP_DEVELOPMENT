import React from 'react'

const Addstudent = () => {
  return (
    <div className='Add-Student'>
      
    </div>
  )
}

export default Addstudent
